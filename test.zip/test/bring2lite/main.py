from classes.gui import GUI
import logging
def main():
    my_gui = GUI()
    my_gui.process()

if __name__ == "__main__":
    main()
