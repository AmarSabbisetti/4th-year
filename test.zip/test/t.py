import sqlite3
import os
conn= sqlite3.connect('evidence.db')
print(conn)
cur=conn.cursor()
values = ('yash', '42') #os.stat(item).st_size
cur.execute("INSERT INTO Evidence VALUES (?, ?)", values)
cur.execute(('select * from Evidence;'))
print(cur.fetchall())